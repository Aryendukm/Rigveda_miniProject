from django.contrib import admin
from .models import userinfo,ans


# Register your models here. super-aditya Aditya123
admin.site.register(userinfo)

admin.site.register(ans)