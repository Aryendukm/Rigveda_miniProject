# RIGVEDA
<h2>Web development project</h2>
<p>to run project go to cmd promt and install django by typing -"pip install django"</p>
<p>then install pillow by cmd - "pip install pillow"</p>
<p>go to the project folder then </p>
<p>run project by cmd-"python manage.py runserver</p>



<h3>Yoga recommendation system</h3>
